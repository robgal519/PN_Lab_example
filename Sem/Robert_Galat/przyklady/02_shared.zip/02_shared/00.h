#ifndef a_00_h
#define a_00_h

int global=15;

int add(int a, int b);
#endif