#include "00.h"

int main()
{
	return add(global,-1);
}